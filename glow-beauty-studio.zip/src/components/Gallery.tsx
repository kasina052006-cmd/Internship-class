import bridal from "@/assets/gallery-bridal.jpg";
import spa from "@/assets/gallery-spa.jpg";
import hair from "@/assets/gallery-hair.jpg";
import skin from "@/assets/gallery-skin.jpg";
import interior from "@/assets/interior-1.jpg";

const images = [
  { src: bridal, alt: "Bridal makeup at Glow Beauty Studio", label: "Bridal Glam", className: "md:row-span-2 md:col-span-1" },
  { src: interior, alt: "Salon interior", label: "Our Studio", className: "" },
  { src: spa, alt: "Spa treatment with rose petals", label: "Spa Rituals", className: "" },
  { src: hair, alt: "Hair styling tools", label: "Hair Artistry", className: "" },
  { src: skin, alt: "Luxury skincare products", label: "Skin Care", className: "" },
];

const Gallery = () => {
  return (
    <section id="gallery" className="py-24 md:py-32 bg-gradient-soft">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-xs tracking-[0.3em] uppercase text-primary mb-4">Gallery</p>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-6">
            Moments of <em className="text-gradient-rose">transformation</em>
          </h2>
          <p className="text-foreground/70">A glimpse into our studio and the radiance we love to create.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-4 md:gap-6 md:auto-rows-[260px]">
          {images.map((img, i) => (
            <div
              key={i}
              className={`relative group rounded-2xl overflow-hidden shadow-soft cursor-pointer ${img.className}`}
            >
              <img
                src={img.src}
                alt={img.alt}
                width={800}
                height={800}
                loading="lazy"
                className="w-full h-full object-cover transition-smooth group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-smooth" />
              <div className="absolute bottom-4 left-4 text-primary-foreground font-serif text-2xl opacity-0 group-hover:opacity-100 transition-smooth translate-y-2 group-hover:translate-y-0">
                {img.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;
