import { Scissors, Sparkles, Palette, Crown, Flower2 } from "lucide-react";

const categories = [
  {
    icon: Scissors,
    name: "Hair",
    items: [
      { name: "Signature Cut & Style", price: "$65" },
      { name: "Balayage / Highlights", price: "$180" },
      { name: "Keratin Smoothing", price: "$220" },
      { name: "Hair Spa Ritual", price: "$85" },
    ],
  },
  {
    icon: Sparkles,
    name: "Skin Care",
    items: [
      { name: "Glow Hydra Facial", price: "$120" },
      { name: "Anti-Aging Treatment", price: "$150" },
      { name: "Brightening Peel", price: "$100" },
      { name: "Express Radiance Facial", price: "$70" },
    ],
  },
  {
    icon: Palette,
    name: "Makeup",
    items: [
      { name: "Day Glam", price: "$80" },
      { name: "Evening Soirée", price: "$110" },
      { name: "HD Airbrush", price: "$140" },
      { name: "Lash Application", price: "$35" },
    ],
  },
  {
    icon: Crown,
    name: "Bridal Packages",
    items: [
      { name: "Bridal Trial", price: "$150" },
      { name: "Classic Bridal Look", price: "$450" },
      { name: "Royal Bridal Suite", price: "$899" },
      { name: "Bridesmaid Glam", price: "$95" },
    ],
  },
  {
    icon: Flower2,
    name: "Spa",
    items: [
      { name: "Aromatherapy Massage", price: "$130" },
      { name: "Hot Stone Therapy", price: "$160" },
      { name: "Body Polish Ritual", price: "$110" },
      { name: "Couples Retreat", price: "$280" },
    ],
  },
];

const Services = () => {
  return (
    <section id="services" className="py-24 md:py-32">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-xs tracking-[0.3em] uppercase text-primary mb-4">Our Services</p>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-6">
            Curated <em className="text-gradient-rose">beauty</em> rituals
          </h2>
          <p className="text-foreground/70">
            From everyday refreshes to bridal moments — find the experience designed for you.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((cat) => (
            <div
              key={cat.name}
              className="group relative bg-card rounded-3xl p-8 border border-border/60 shadow-soft hover:shadow-elegant transition-smooth hover:-translate-y-2"
            >
              <div className="inline-flex p-4 rounded-2xl bg-gradient-rose text-primary-foreground mb-6 shadow-soft">
                <cat.icon className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-3xl mb-6">{cat.name}</h3>
              <ul className="space-y-4">
                {cat.items.map((item) => (
                  <li key={item.name} className="flex justify-between items-baseline gap-3 pb-3 border-b border-dashed border-border/70 last:border-0">
                    <span className="text-sm text-foreground/80">{item.name}</span>
                    <span className="font-serif text-lg text-primary whitespace-nowrap">{item.price}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
