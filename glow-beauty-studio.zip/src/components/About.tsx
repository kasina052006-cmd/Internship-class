import { Heart, Award, Leaf } from "lucide-react";
import interior from "@/assets/interior-1.jpg";

const About = () => {
  return (
    <section id="about" className="py-24 md:py-32 bg-gradient-soft">
      <div className="container grid lg:grid-cols-2 gap-16 items-center">
        <div className="relative animate-fade-in">
          <div className="absolute -inset-4 bg-gradient-rose rounded-3xl opacity-20 blur-2xl" />
          <img
            src={interior}
            alt="Elegant Glow Beauty Studio interior"
            width={800}
            height={800}
            loading="lazy"
            className="relative rounded-3xl shadow-elegant w-full"
          />
          <div className="absolute -bottom-8 -right-4 md:-right-8 bg-card rounded-2xl shadow-elegant p-6 max-w-[220px] border border-border">
            <div className="font-serif text-4xl text-primary">12+</div>
            <p className="text-sm text-muted-foreground mt-1">Years crafting beauty experiences</p>
          </div>
        </div>

        <div>
          <p className="text-xs tracking-[0.3em] uppercase text-primary mb-4">About Us</p>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-6 leading-tight">
            Where artistry becomes <em className="text-gradient-rose">ritual</em>
          </h2>
          <p className="text-foreground/75 leading-relaxed mb-6">
            At Glow Beauty Studio, every visit is a personal sanctuary. Our award-winning stylists, estheticians and makeup artists blend timeless technique with modern innovation to bring out the best in you.
          </p>
          <p className="text-foreground/75 leading-relaxed mb-10">
            Our mission is simple — to make every guest feel seen, celebrated and effortlessly radiant.
          </p>

          <div className="grid sm:grid-cols-3 gap-6">
            {[
              { icon: Heart, title: "Personalized", desc: "Tailored to you" },
              { icon: Award, title: "Award Team", desc: "Certified experts" },
              { icon: Leaf, title: "Clean Beauty", desc: "Premium products" },
            ].map((f) => (
              <div key={f.title} className="text-center p-4 rounded-xl bg-card/60 border border-border/60">
                <div className="inline-flex p-3 rounded-full bg-primary/10 text-primary mb-3">
                  <f.icon className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-lg">{f.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
