import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import hero from "@/assets/hero.jpg";

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <img src={hero} alt="Glow Beauty Studio luxurious salon interior" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="absolute inset-0 bg-background/30" />
      </div>

      <div className="container relative z-10 pt-24">
        <div className="max-w-2xl animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-background/70 backdrop-blur-sm border border-primary/20 mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs font-medium tracking-widest uppercase text-foreground/80">Luxury Beauty Studio</span>
          </div>

          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl leading-[1.05] mb-6 text-foreground">
            Reveal Your <span className="text-gradient-rose italic">Natural</span> Glow
          </h1>

          <p className="text-lg md:text-xl text-foreground/75 mb-10 max-w-xl leading-relaxed">
            An indulgent escape where artistry meets care. Discover bespoke hair, skin, makeup and spa rituals designed just for you.
          </p>

          <div className="flex flex-wrap gap-4">
            <Button asChild size="lg" className="bg-gradient-rose text-primary-foreground hover:opacity-90 rounded-full px-8 h-14 text-base shadow-elegant">
              <a href="#booking">Book Your Visit</a>
            </Button>
            <Button asChild size="lg" variant="outline" className="rounded-full px-8 h-14 text-base border-foreground/20 bg-background/60 backdrop-blur-sm hover:bg-background">
              <a href="#services">Explore Services</a>
            </Button>
          </div>

          <div className="mt-16 grid grid-cols-3 gap-8 max-w-md">
            {[
              { n: "12+", l: "Years of Care" },
              { n: "8K+", l: "Happy Clients" },
              { n: "30+", l: "Signature Services" },
            ].map((s) => (
              <div key={s.l}>
                <div className="font-serif text-3xl md:text-4xl text-primary">{s.n}</div>
                <div className="text-xs md:text-sm text-foreground/70 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
