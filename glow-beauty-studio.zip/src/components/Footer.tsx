import { Instagram, Facebook } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background/90 pt-20 pb-8">
      <div className="container grid md:grid-cols-4 gap-12 mb-12">
        <div className="md:col-span-2">
          <h3 className="font-serif text-3xl mb-4">
            <span className="text-gradient-rose">Glow</span> Beauty Studio
          </h3>
          <p className="text-background/70 leading-relaxed max-w-md mb-6">
            A luxury beauty sanctuary where artistry, care and confidence meet. Your glow, perfected.
          </p>
          <div className="flex gap-3">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
              className="p-2.5 rounded-full border border-background/20 hover:bg-gradient-rose hover:border-transparent transition-smooth">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook"
              className="p-2.5 rounded-full border border-background/20 hover:bg-gradient-rose hover:border-transparent transition-smooth">
              <Facebook className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-serif text-lg mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm text-background/70">
            {["About", "Services", "Gallery", "Reviews", "Booking", "Contact"].map((l) => (
              <li key={l}>
                <a href={`#${l.toLowerCase()}`} className="hover:text-primary-foreground hover:text-blush transition-smooth">{l}</a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-serif text-lg mb-4">Business Hours</h4>
          <ul className="space-y-2 text-sm text-background/70">
            <li className="flex justify-between gap-4"><span>Mon – Fri</span><span>9:00 – 20:00</span></li>
            <li className="flex justify-between gap-4"><span>Saturday</span><span>9:00 – 18:00</span></li>
            <li className="flex justify-between gap-4"><span>Sunday</span><span>10:00 – 16:00</span></li>
          </ul>
        </div>
      </div>

      <div className="container pt-8 border-t border-background/10 text-xs text-background/50 flex flex-col md:flex-row justify-between gap-3">
        <p>© {new Date().getFullYear()} Glow Beauty Studio. All rights reserved.</p>
        <p>Crafted with love & a little sparkle ✨</p>
      </div>
    </footer>
  );
};

export default Footer;
