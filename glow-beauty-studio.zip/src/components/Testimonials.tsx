import { Star, Quote } from "lucide-react";

const reviews = [
  {
    name: "Sophia Laurent",
    role: "Bridal Client",
    text: "The bridal team made me feel like royalty. My makeup lasted from sunrise ceremony to midnight dancing — flawless.",
  },
  {
    name: "Aisha Patel",
    role: "Regular Guest",
    text: "Their hydra facial completely transformed my skin. I leave glowing every single time. The studio is a dream.",
  },
  {
    name: "Maria Chen",
    role: "Hair Color Client",
    text: "Best balayage I've ever had. The team genuinely listens and crafts a look that's uniquely you. Pure artistry.",
  },
];

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-24 md:py-32">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-xs tracking-[0.3em] uppercase text-primary mb-4">Kind Words</p>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-6">
            Loved by our <em className="text-gradient-rose">guests</em>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6 md:gap-8">
          {reviews.map((r) => (
            <div
              key={r.name}
              className="relative bg-card rounded-3xl p-8 border border-border/60 shadow-soft hover:shadow-elegant transition-smooth"
            >
              <Quote className="absolute top-6 right-6 w-10 h-10 text-primary/15" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="text-foreground/80 leading-relaxed mb-6 font-serif text-lg italic">"{r.text}"</p>
              <div className="pt-4 border-t border-border/60">
                <div className="font-medium">{r.name}</div>
                <div className="text-xs text-muted-foreground">{r.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
