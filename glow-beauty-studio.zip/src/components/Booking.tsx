import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Sparkles } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { z } from "zod";

const schema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(80),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().min(6, "Phone is too short").max(20),
  service: z.string().min(1, "Please select a service"),
  time: z.string().min(1, "Please pick a time"),
  date: z.date({ required_error: "Please pick a date" }),
});

const services = ["Hair Cut & Style", "Hair Color", "Glow Hydra Facial", "Bridal Package", "Spa Massage", "Makeup Session"];
const times = ["09:00", "10:30", "12:00", "14:00", "15:30", "17:00", "18:30"];

const Booking = () => {
  const [date, setDate] = useState<Date>();
  const [form, setForm] = useState({ name: "", email: "", phone: "", service: "", time: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse({ ...form, date });
    if (!result.success) {
      toast.error(result.error.issues[0].message);
      return;
    }
    toast.success("Booking received! We'll confirm shortly.", {
      description: `${result.data.service} on ${format(result.data.date, "PPP")} at ${result.data.time}`,
    });
    setForm({ name: "", email: "", phone: "", service: "", time: "" });
    setDate(undefined);
  };

  return (
    <section id="booking" className="py-24 md:py-32 bg-gradient-soft relative overflow-hidden">
      <div className="absolute -top-20 -right-20 w-96 h-96 bg-gradient-rose rounded-full opacity-20 blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-blush rounded-full opacity-30 blur-3xl" />

      <div className="container relative">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="lg:sticky lg:top-32">
            <p className="text-xs tracking-[0.3em] uppercase text-primary mb-4">Book Now</p>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-6 leading-tight">
              Reserve your <em className="text-gradient-rose">moment</em>
            </h2>
            <p className="text-foreground/75 mb-8 leading-relaxed">
              Choose your service, pick a time that suits you, and our team will confirm your appointment with care.
            </p>
            <div className="flex items-center gap-3 text-sm text-foreground/70">
              <Sparkles className="w-4 h-4 text-primary" />
              Complimentary consultation included
            </div>
          </div>

          <form onSubmit={submit} className="bg-card rounded-3xl shadow-elegant p-8 md:p-10 border border-border/60 space-y-5">
            <div className="grid md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Jane Doe" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 555 1234" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
            </div>

            <div className="space-y-2">
              <Label>Service</Label>
              <Select value={form.service} onValueChange={(v) => setForm({ ...form, service: v })}>
                <SelectTrigger><SelectValue placeholder="Select a service" /></SelectTrigger>
                <SelectContent>
                  {services.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="grid md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      disabled={(d) => d < new Date(new Date().setHours(0, 0, 0, 0))}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>Time</Label>
                <Select value={form.time} onValueChange={(v) => setForm({ ...form, time: v })}>
                  <SelectTrigger><SelectValue placeholder="Pick a time" /></SelectTrigger>
                  <SelectContent>
                    {times.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full bg-gradient-rose text-primary-foreground hover:opacity-90 rounded-full h-14 text-base shadow-elegant mt-2">
              Confirm Booking
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Booking;
