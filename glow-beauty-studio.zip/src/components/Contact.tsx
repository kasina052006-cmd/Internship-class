import { Phone, Mail, MapPin, Instagram, Facebook } from "lucide-react";

const Contact = () => {
  return (
    <section id="contact" className="py-24 md:py-32">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-xs tracking-[0.3em] uppercase text-primary mb-4">Visit Us</p>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl mb-6">
            Come say <em className="text-gradient-rose">hello</em>
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-10">
          <div className="space-y-6">
            {[
              { icon: Phone, label: "Phone", value: "+1 (555) 234-5678", href: "tel:+15552345678" },
              { icon: Mail, label: "Email", value: "hello@glowbeautystudio.com", href: "mailto:hello@glowbeautystudio.com" },
              { icon: MapPin, label: "Address", value: "128 Rose Avenue, Beverly Hills, CA 90210" },
            ].map((c) => (
              <a
                key={c.label}
                href={c.href || "#"}
                className="flex items-start gap-5 p-6 bg-card rounded-2xl border border-border/60 shadow-soft hover:shadow-elegant transition-smooth group"
              >
                <div className="p-3 rounded-xl bg-gradient-rose text-primary-foreground shadow-soft group-hover:scale-110 transition-smooth">
                  <c.icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs tracking-widest uppercase text-muted-foreground mb-1">{c.label}</div>
                  <div className="font-serif text-xl">{c.value}</div>
                </div>
              </a>
            ))}

            <div className="p-6 bg-gradient-soft rounded-2xl border border-border/60">
              <h3 className="font-serif text-2xl mb-4">Follow Our Glow</h3>
              <div className="flex gap-3">
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                  className="p-3 rounded-full bg-card border border-border hover:bg-gradient-rose hover:text-primary-foreground hover:border-transparent transition-smooth">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook"
                  className="p-3 rounded-full bg-card border border-border hover:bg-gradient-rose hover:text-primary-foreground hover:border-transparent transition-smooth">
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          <div className="rounded-3xl overflow-hidden shadow-elegant border border-border/60 min-h-[420px]">
            <iframe
              title="Glow Beauty Studio location"
              src="https://www.google.com/maps?q=Beverly+Hills,+CA&output=embed"
              width="100%"
              height="100%"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-full h-full min-h-[420px] border-0"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
